<?php

use Illuminate\Support\Facades\Route;
// use App\Http\Controllers\TemperaturaController;


// Route::post("temperatura", [TemperaturaController::class, "store"])->name("temperaturas.store");